package com.gsrtc.mobileweb.ui.activities.advance_booking;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.gsrtc.mobileweb.R;
import com.gsrtc.mobileweb.models.Booking;
import com.gsrtc.mobileweb.ui.activities.HomeActivity;
import com.gsrtc.mobileweb.ui.activities.base.BaseNavigationDrawerActivity;
import com.gsrtc.mobileweb.ui.activities.payment_gateway.CCAvenueWebview;
import com.gsrtc.mobileweb.utils.ActivityUtil;
import com.gsrtc.mobileweb.utils.AppConstants;
import com.gsrtc.mobileweb.utils.customdialog.CustomisedProgressDialog;

public class ReferenceNumberActivity extends BaseNavigationDrawerActivity {

    ProgressDialog seatBlockingProgressDialog;
    Booking onwardBooking, returnBooking;
    public static final int PAYMENT_CODE = 26;
    private String totalFare, paymentMode;
    private String isCard;
    String textlang;

    TextView title,text_up,text_down;
    Button nextbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentViewDrawer(R.layout.activity_reference_number);

        Bundle extras = getIntent().getExtras();
        onwardBooking = (Booking) extras.getSerializable(AppConstants.INTENT_EXTRA.BOOKING_ONWARD);
        totalFare = extras.getString("totalFare", null);
        paymentMode = extras.getString("paymentMode", null);
        isCard = extras.getString("iscard", null);

//        if (paymentMode.equals("HDFC"))
//            isCard = false;
//        else
//            isCard = true;

        textlang = onwardBooking.getSearchParams().getTextlanguage().trim();

        title = (TextView)findViewById(R.id.header_text);
        text_up = (TextView)findViewById(R.id.text_up);
        text_down = (TextView)findViewById(R.id.text_bottom);
        nextbtn = (Button)findViewById(R.id.submitBtn);

        if(textlang.equalsIgnoreCase("gujarati"))
        {
            title.setText(R.string.ob_make_pay);
            text_up.setText(R.string.ob_text_up);
            text_down.setText(R.string.ob_text_down);
            nextbtn.setText(R.string.ob_btn_cnfrm);
        }

        if (onwardBooking.getSaveBookingDetailsTemporary() != null) {
            ((TextView) findViewById(R.id.onwardJourney)).setText(onwardBooking.getSaveBookingDetailsTemporary().getRtcRefNo());
        }

        if (extras.containsKey(AppConstants.INTENT_EXTRA.BOOKING_RETURN)) {
            returnBooking = (Booking) extras.getSerializable(AppConstants.INTENT_EXTRA.BOOKING_RETURN);
            if (returnBooking.getSaveReturnBookingDetailsTemporary() != null) {

                ((TextView) findViewById(R.id.onwardJourney)).setText(returnBooking.getSaveReturnBookingDetailsTemporary().getRtcRefNo());

            }
        }

       nextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pay();
            }
        });
    }

    public void onBookingConfirmed() {
        if (totalFare == null)
            return;
        if (isCard.equalsIgnoreCase("694")) {
            Intent intent = new Intent(ReferenceNumberActivity.this,CCAvenueWebview.class);
            intent.putExtra("textlang", textlang);
            intent.putExtra(AppConstants.INTENT_EXTRA.BOOKING_ONWARD, onwardBooking);
            if (returnBooking != null) {
                intent.putExtra(AppConstants.INTENT_EXTRA.BOOKING_RETURN, returnBooking);
            }
            intent.putExtra("totalFare", totalFare);
            intent.putExtra("isCard", isCard);
            startActivityForResult(intent, PAYMENT_CODE);
        } else {

            Intent intent = new Intent(ReferenceNumberActivity.this,  BillDeskGateway.class);
            intent.putExtra("textlang", textlang);
            intent.putExtra(AppConstants.INTENT_EXTRA.BOOKING_ONWARD, onwardBooking);
            if (returnBooking != null) {
                intent.putExtra(AppConstants.INTENT_EXTRA.BOOKING_RETURN, returnBooking);
            }
            intent.putExtra("totalFare", totalFare);
            intent.putExtra("isCard", isCard);
            startActivityForResult(intent, PAYMENT_CODE);
        }
    }

    /***RETRIVE THE VALUE FROM HDFC & BILLDESK PAYMENT ACTIVITY  ***/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PAYMENT_CODE) {
            if (resultCode == RESULT_OK) {

                Booking onwardBooking1 = (Booking) data.getExtras().getSerializable(AppConstants.INTENT_EXTRA.BOOKING_ONWARD);

                if (onwardBooking1 == null) {
                    //hideProgressDialog();
                    CustomisedProgressDialog.STOP_CUST_DIA();
                    return;
                }

                if (data.getExtras().containsKey(AppConstants.INTENT_EXTRA.BOOKING_RETURN)) {
                    Booking returnBooking1 = (Booking) data.getExtras().getSerializable(AppConstants.INTENT_EXTRA.BOOKING_RETURN);
                    if (onwardBooking1.getConfirmRtnSeatBookingAndroidResponse() != null && returnBooking1.getConfirmRtnSeatBookingAndroidResponse() != null) {
                        onwardBooking = onwardBooking1;
                        returnBooking = returnBooking1;

                    } else {
                        Log.d("No Luck", "No Luck");
                       // hideProgressDialog();
                        CustomisedProgressDialog.STOP_CUST_DIA();
                        return;
                    }
                } else {
                    if (onwardBooking1.getConfirmAdvSeatBookingAndroidResponse() != null) {
                        onwardBooking = onwardBooking1;

                    } else {
                        Log.d("No Luck", "No Luck");
                        //hideProgressDialog();
                        CustomisedProgressDialog.STOP_CUST_DIA();
                        return;
                    }
                }

               //hideProgressDialog();
                CustomisedProgressDialog.STOP_CUST_DIA();
                Bundle extras = new Bundle();
                extras.putString("textlang", textlang);
                extras.putSerializable(AppConstants.INTENT_EXTRA.BOOKING_ONWARD, onwardBooking);
                if (returnBooking != null)
                    extras.putSerializable(AppConstants.INTENT_EXTRA.BOOKING_RETURN, returnBooking);
                ActivityUtil.openNewActivity(ReferenceNumberActivity.this, BookingSuccessActivity.class, extras);
            } else if (resultCode == RESULT_CANCELED)
            {
                //hideProgressDialog();
                CustomisedProgressDialog.STOP_CUST_DIA();
            }
        }
    }

    public void pay() {
        CustomisedProgressDialog.SHOW_CUST_DIA(ReferenceNumberActivity.this, "Please wait Confirming Ticket...");

        onBookingConfirmed();
    }

    public void showProgressDialog() {
        if (seatBlockingProgressDialog != null && seatBlockingProgressDialog.isShowing()) {
            return;
        }
        seatBlockingProgressDialog = new ProgressDialog(this);
        seatBlockingProgressDialog.setCancelable(false);
        seatBlockingProgressDialog.setTitle("Confirming Ticket...");
        seatBlockingProgressDialog.setMessage("Please wait...");
        seatBlockingProgressDialog.show();
    }

    public void hideProgressDialog() {
        if (seatBlockingProgressDialog == null || !seatBlockingProgressDialog.isShowing()) {
            return;
        }
        seatBlockingProgressDialog.dismiss();
    }

    public void onBackPressed() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                ReferenceNumberActivity.this,R.style.CustomDialogTheme);

        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //ActivityUtil.openNewActivityAsOnlyActivity(ReferenceNumberActivity.this, HomeActivity.class, null);
                Intent i = new Intent(ReferenceNumberActivity.this, HomeActivity.class);
                Bundle data = new Bundle();
                data.putString("textlang", textlang);
                i.putExtras(data);
                startActivity(i);
            }
        });

        alertDialog.setNegativeButton("NO", null);

        alertDialog.setMessage("Going back will discard your booking. Do you want to continue?");
        alertDialog.setTitle("GSRTC");
        alertDialog.show();
    }
}
