package com.gsrtc.mobileweb.utils.net;

import com.gsrtc.mobileweb.utils.SoapClientUtil;

/**
 * Created by Swastik on 4/25/2017.
 */

public class CurrentBookingNetworkUtil extends SoapClientUtil {
}
