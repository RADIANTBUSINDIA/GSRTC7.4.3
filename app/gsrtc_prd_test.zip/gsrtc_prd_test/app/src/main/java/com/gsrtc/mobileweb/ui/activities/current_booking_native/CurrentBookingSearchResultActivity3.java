package com.gsrtc.mobileweb.ui.activities.current_booking_native;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.gsrtc.mobileweb.R;
import com.gsrtc.mobileweb.models.BusCurrentService;
import com.gsrtc.mobileweb.models.BusGetRouteDetails;
import com.gsrtc.mobileweb.models.RouteListAdapter;
import com.gsrtc.mobileweb.models.SearchParamsCurrent;
import com.gsrtc.mobileweb.ui.activities.base.BaseNavigationDrawerActivity;
import com.gsrtc.mobileweb.utils.ActivityUtil;
import com.gsrtc.mobileweb.utils.AppConstants;
import com.gsrtc.mobileweb.utils.SoapClientUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bala on 02-01-2018.
 */

public class CurrentBookingSearchResultActivity3 extends BaseNavigationDrawerActivity {

    SearchParamsCurrent searchParams;
    ActivityViewHolder vHolder;
    SearchResultAdapter searchResultAdapter;
    List<BusCurrentService> busServiceList = new ArrayList<>();
    List<BusGetRouteDetails> busRouteList = new ArrayList<>();
    boolean dataFetched = false;

    static String StartPlaceID;
    static String EndPlaceID;
    static String AdultMales;
    static String AdultFemale;
    static String ChildMales;
    static String ChildFemale;
    static String JourneyDate;
    static String PickServiceId;
    static String ClassId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentViewDrawer(R.layout.activity_current_booking_search_result_screen3);

        if(getIntent()!=null && getIntent().getExtras()!=null){
            searchParams = (SearchParamsCurrent) getIntent().getExtras().getSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM);

            //StartPlaceID = searchParams.getStartPlaceID();

            StartPlaceID = searchParams.getFromLocation().getPlaceID();
            EndPlaceID = searchParams.getToLocation().getPlaceID();

            /*AdultMales = searchParams.getAdultMales();
            AdultFemale = searchParams.getAdultFemale();
            ChildMales = searchParams.getChildMales();
            ChildFemale = searchParams.getChildFemale();*/

        }

        // AccordionWidget accordionWidget = (AccordionWidget) findViewById(R.id.travel_details_accordion);
        //accordionWidget.setExpandLayout(findViewById(R.id.travel_details_content));

        setupViews();
    }

    public void setupViews() {
        vHolder = new ActivityViewHolder(this);

        vHolder.header_text.setText(searchParams.getFromLocation().getPlaceName() + " to " + searchParams.getToLocation().getPlaceName());
        setupListView(null);
        vHolder.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Your code to refresh the list here.
                // Make sure you call swipeContainer.setRefreshing(false)
                // once the network request has completed successfully.
                vHolder.swipeContainer.setRefreshing(false);
                if(!dataFetched){
                    vHolder.loadingLayout.setVisibility(View.VISIBLE);
                    vHolder.recyclerView.setVisibility(View.GONE);
                }
                fetchAvailableServices();
            }
        });



        fetchAvailableServices();
    }

    /*public void setupRouteView() {
        vHolder = new ActivityViewHolder(this);

        //vHolder.header_text.setText(searchParams.getFromLocation().getPlaceName() + " to " + searchParams.getToLocation().getPlaceName());
        setupListView(null);
        vHolder.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Your code to refresh the list here.
                // Make sure you call swipeContainer.setRefreshing(false)
                // once the network request has completed successfully.
                vHolder.swipeContainer.setRefreshing(false);
                if(!dataFetched){
                    vHolder.loadingLayout.setVisibility(View.VISIBLE);
                    vHolder.recyclerView.setVisibility(View.GONE);
                }
                fetchRouteDetails();
            }
        });

        fetchRouteDetails();
    }*/

    public void setupListView(List<BusCurrentService> serviceList){
        searchResultAdapter = new SearchResultAdapter(this, serviceList) {
            @Override
            public void onItemClick(BusCurrentService busService) {
                /*Bundle extra = new Bundle();
                extra.putSerializable(AppConstants.INTENT_EXTRA.BUS_SERVICE, busService);
                extra.putSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM, searchParams);*/
                /*Bundle bundle = new Bundle();
                bundle.putString("JourneyDate", busService.getJourneyDate());
                bundle.putString("PickServiceId", busService.getPickServiceId());
                bundle.putString("ClassId", busService.getClassID());
                bundle.putString("StartPlaceID", StartPlaceID);
                bundle.putString("EndPlaceID", EndPlaceID);
                bundle.putString("AdultMales", AdultMales);
                bundle.putString("AdultFemale", AdultFemale);
                bundle.putString("ChildMales", ChildMales);
                bundle.putString("ChildFemale", ChildFemale);
                bundle.putString("ConcessionID", "79");
                bundle.putString("OnewayOrReturnTrip","O");
                Intent intent = new Intent(CurrentBookingSearchResultActivity.this, GetCurrentSummaryActivity.class);
                intent.putExtras(bundle);
                //startActivityForResult(intent, SEAT_SELECTION_REQUEST);
                //startActivityForResult(intent, SEAT_SELECTION_REQUEST);
                startActivity(intent);*/
            }


        };

        LinearLayoutManager layoutManager  = new LinearLayoutManager(this);
        vHolder.recyclerView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(vHolder.recyclerView.getContext(),
                layoutManager.getOrientation() );
        vHolder.recyclerView.addItemDecoration(dividerItemDecoration);
        vHolder.recyclerView.setAdapter(searchResultAdapter);
        searchResultAdapter.notifyDataSetChanged();
    }

    public static class ActivityViewHolder{
        View rootView, loadingLayout;
        RecyclerView recyclerView;
        TextView header_text;
        SwipeRefreshLayout swipeContainer;
        //Button dep_time_btn, class_btn, price_btn;

        ActivityViewHolder(Activity activity){
            rootView = activity.findViewById(R.id.rootView);
            header_text = (TextView)activity.findViewById(R.id.header_text);
            swipeContainer = (SwipeRefreshLayout) activity.findViewById(R.id.swipeContainer);
            loadingLayout =  activity.findViewById(R.id.search_results_loading);
            recyclerView = (RecyclerView) activity.findViewById(R.id.search_results_recycler_view);

            //dep_time_btn =  (Button)activity.findViewById(R.id.dep_time_btn);
            //class_btn =  (Button)activity.findViewById(R.id.class_btn);
            //price_btn =  (Button)activity.findViewById(R.id.bus_running_status);

            ActivityUtil.loadLoadingImage(activity, (ImageView)activity.findViewById(R.id.loading_gif));
        }
    }

    public static class RouteViewHolder{
        View rootView, loadingLayout;
        RecyclerView recyclerView;
        TextView header_text;
        SwipeRefreshLayout swipeContainer;
        //Button dep_time_btn, class_btn, price_btn;

        RouteViewHolder(Activity activity){
            rootView = activity.findViewById(R.id.rootView);
            header_text = (TextView)activity.findViewById(R.id.header_text);
            swipeContainer = (SwipeRefreshLayout) activity.findViewById(R.id.swipeContainer);
            loadingLayout =  activity.findViewById(R.id.search_results_loading);
            recyclerView = (RecyclerView) activity.findViewById(R.id.search_results_recycler_view);

            //dep_time_btn =  (Button)activity.findViewById(R.id.dep_time_btn);
            //class_btn =  (Button)activity.findViewById(R.id.class_btn);
            //price_btn =  (Button)activity.findViewById(R.id.bus_running_status);

            ActivityUtil.loadLoadingImage(activity, (ImageView)activity.findViewById(R.id.loading_gif));
        }
    }

    abstract class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.ViewHolder>{

        private List<BusCurrentService> busList;
        Context context;

        public SearchResultAdapter(Context context, List<BusCurrentService> busList) {
            if(busList == null)
                busList = new ArrayList<BusCurrentService>();
            this.busList = busList;
            this.context = context;
        }


        @Override
        public SearchResultAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            Context context = parent.getContext();
            LayoutInflater inflater = LayoutInflater.from(context);

            // Inflate the custom layout
            View contactView = inflater.inflate(R.layout.current_booking_list_item3, parent, false);

            // Return a new holder instance
            return new SearchResultAdapter.ViewHolder(contactView);
        }



        @Override
        public void onBindViewHolder(final SearchResultAdapter.ViewHolder holder, final int position) {
            final BusCurrentService busService = this.busList.get(position);


            holder.container.setTag(position);
            holder.container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Integer pos = (Integer)view.getTag();
                    Log.e("Position", String.valueOf(pos));
                    onItemClick(busList.get(pos));
                }
            });

            holder.tvServiceRouteName.setText(busService.getServiceRouteName());
            holder.tvDeparted.setText(busService.getDepartureTime());
            holder.tvVehicleNo.setText(busService.getVehicleNo());
            holder.tvBusRunningStatus.setText(busService.getVehicleStatus());
            holder.btnBook.setText("Book \u20B9"+busService.getAdultFare());

            JourneyDate = busService.getJourneyDate();
            Log.e("JourneyDate", busService.getJourneyDate());
            PickServiceId = busService.getPickServiceId();
            Log.e("PickServiceId", busService.getPickServiceId());
            ClassId = busService.getClassID();
            Log.e("ClassId", busService.getClassID());

            holder.btnBook.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Log.e("Position", String.valueOf(position));
                    Log.e("adultFare", busList.get(position).getAdultFare());
                    Log.e("childFare", busList.get(position).getChildFare());

                    searchParams.setServiceRouteName(holder.tvServiceRouteName.getText().toString());
                    searchParams.setJourneyDate(JourneyDate);
                    searchParams.setPickServiceId(PickServiceId);
                    searchParams.setClassId(ClassId);

                    searchParams.setAdultFareServiceDetails(busList.get(position).getAdultFare());
                    searchParams.setChildFareServiceDetails(busList.get(position).getChildFare());


                    Bundle extra = new Bundle();
                    extra.putSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM, searchParams);
                    ActivityUtil.openNewActivity(v.getContext(), GetCurrentSummaryActivity.class, extra);
                    //ActivityUtil.openNewActivity(v.getContext(), Summary_Passenger_DetailsActivity.class, extra);

                }
            });

            holder.linearLayoutRouteDetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    /*String pickServiceID = busList.get(position).getPickServiceId();
                    Log.e("Pick ServiceID", pickServiceID);
                    fetchRouteDetails(pickServiceID);*/
                    String pickServiceID = busList.get(position).getPickServiceId();
                    startRouteDetailsDialog(pickServiceID);

                }
            });

            //searchParams.setJourneyDate(busService.getJourneyDate());


            /*holder.linearLayoutRouteDetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //Log.e("Route Details", "clicked");
                    fetchRouteDetails();

                }
            });*/
            //holder.price.setText("INR "+busService.getAdultFare());
            /*holder.booking_class.setText(busService.getServiceClass());
            holder.departure_time.setText(busService.getDepartureTime());
            holder.price.setText("INR "+busService.getAdultFare());
            holder.bus_route.setText(busService.getOrigin()+"-"+busService.getDestination());*/
        }

        private void startRouteDetailsDialog(String pickServiceID) {

            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(CurrentBookingSearchResultActivity3.this);
            final AlertDialog alertDialog = dialogBuilder.create();
            alertDialog.setCanceledOnTouchOutside(false);
            alertDialog.show();

            LayoutInflater inflater = CurrentBookingSearchResultActivity3.this.getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.route_details_dialog, null);
            alertDialog.getWindow().setContentView(dialogView);
            Button dialogButton = (Button) dialogView.findViewById(R.id.btnRouteDetailsClose);
            final ProgressBar progressBar = (ProgressBar) dialogView.findViewById(R.id.progressBar);
            final ListView listView = (ListView) dialogView.findViewById(R.id.lvRouteDetails);
            dialogButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                }
            });
            SoapClientUtil.getRouteDetails(searchParams, pickServiceID, new SoapClientUtil.GetRouteDetailsCallback() {
                @Override
                public void onSuccess(List<BusGetRouteDetails> routeDetailsList) {

                    busRouteList = routeDetailsList;
                    RouteListAdapter routeListAdapter = new RouteListAdapter(CurrentBookingSearchResultActivity3.this, R.layout.route_details_listview_item, busRouteList);
                    listView.setAdapter(routeListAdapter);
                    progressBar.setVisibility(View.GONE);
                    listView.setVisibility(View.VISIBLE);


                }

                @Override
                public void onError(Exception e) {

                }
            });

        }
        // Clean all elements of the recycler
        public void clear() {
            busList.clear();
            notifyDataSetChanged();
        }

        // Add a list of items
        public void addAll(List<BusCurrentService> list) {
            busList.addAll(list);
            notifyDataSetChanged();
        }

        public abstract void onItemClick(BusCurrentService site);

        @Override
        public int getItemCount() {
            return busList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvServiceRouteName, tvVehicleNo, tvDeparted;
            TextView tvBusRunningStatus;
            Button btnBook;
            LinearLayout linearLayoutRouteDetails;


            View container;

            ViewHolder(View itemView) {
                super(itemView);
                container = itemView;

                /*booking_class = (TextView) itemView.findViewById(R.id.booking_class);
                bus_route = (TextView) itemView.findViewById(R.id.bus_route);
                departure_time = (TextView) itemView.findViewById(R.id.departure_time);*/
                tvServiceRouteName = (TextView) itemView.findViewById(R.id.li_FromToPlace);
                tvVehicleNo = (TextView) itemView.findViewById(R.id.bus_NO_Text);
                tvDeparted = (TextView) itemView.findViewById(R.id.departed_Text);
                tvBusRunningStatus = (TextView) itemView.findViewById(R.id.bus_running_status_Text);
                btnBook = (Button) itemView.findViewById(R.id.li_book_btn);
                linearLayoutRouteDetails = (LinearLayout)itemView.findViewById(R.id.linearLayoutRouteDetails);



                /*linearLayoutRouteDetails.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //Need to do
                        //setupRouteView();
                    }
                });*/

                /*btnBook.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        searchParams.setJourneyDate(JourneyDate);
                        searchParams.setPickServiceId(PickServiceId);
                        searchParams.setClassId(ClassId);



                        Bundle extra = new Bundle();
                        extra.putSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM, searchParams);
                        ActivityUtil.openNewActivity(v.getContext(), GetCurrentSummaryActivity.class, extra);

                    }
                });*/



            }
        }
    }

    public void fetchAvailableServices(){
        // vHolder.swipeContainer.setRefreshing(true);
        SoapClientUtil.getAvailableCurrentServiceDetails(searchParams, new SoapClientUtil.GetAvailableCurrentServiceDetailsCallback() {
            @Override
            public void onSuccess(List<BusCurrentService> serviceList) {
                busServiceList = serviceList;
                //   sortList(busServiceList, SORT_METHOD.DEP_TIME);
                //onSortBtnClick(vHolder.dep_time_btn);
                setupListView(busServiceList);
                vHolder.loadingLayout.setVisibility(View.GONE);
                vHolder.recyclerView.setVisibility(View.VISIBLE);
                showLoading(false);

            }

            @Override
            public void onError(Exception e) {
                vHolder.loadingLayout.setVisibility(View.GONE);
                showLoading(false);
                ActivityUtil.showErrorToast(CurrentBookingSearchResultActivity3.this, e);
                //  ActivityUtil.showSnackBar(vHolder.rootView, "Server Error");
            }
        });
    }

    public void fetchRouteDetails(String pickServiceId){
        // vHolder.swipeContainer.setRefreshing(true);
        SoapClientUtil.getRouteDetails(searchParams, pickServiceId, new SoapClientUtil.GetRouteDetailsCallback() {
            @Override
            public void onSuccess(List<BusGetRouteDetails> routeDetailsList) {

                busRouteList = routeDetailsList;
                //   sortList(busServiceList, SORT_METHOD.DEP_TIME);
                //onSortBtnClick(vHolder.dep_time_btn);
                //setupListView(busServiceList);
                //vHolder.loadingLayout.setVisibility(View.GONE);
                //vHolder.recyclerView.setVisibility(View.VISIBLE);
                //showLoading(false);

            }

            @Override
            public void onError(Exception e) {
                vHolder.loadingLayout.setVisibility(View.GONE);
                showLoading(false);
                ActivityUtil.showErrorToast(CurrentBookingSearchResultActivity3.this, e);
                //  ActivityUtil.showSnackBar(vHolder.rootView, "Server Error");
            }
        });
    }

    public void showLoading(boolean show){
        if(show){
            vHolder.loadingLayout.setVisibility(View.VISIBLE);
        }
        else{
            vHolder.loadingLayout.setVisibility(View.GONE);
        }
    }
}
