package com.gsrtc.mobileweb.models;

import java.io.Serializable;

/**
 * Created by Swastik on 4/6/2017.
 */

public class SearchParams implements Serializable{

    Boolean isRoundTrip;
    Place fromLocation;
    Place toLocation;
    Integer numOfPassengers;
    String onWardDate, returnDate;
    Integer adultCount = 0;
    Integer adultFemaleCount = 0;
    Integer childrenCount = 0;
    Integer singleLady = 0;
    String textlanguage;

    /*String pickServiceId;
    String JourneyDate;


    public String getPickServiceId() {
        return pickServiceId;
    }

    public void setPickServiceId(String pickServiceId) {
        this.pickServiceId = pickServiceId;
    }*/



    public Boolean getRoundTrip() {
        return isRoundTrip;
    }

    public void setRoundTrip(Boolean roundTrip) {
        isRoundTrip = roundTrip;
    }

    public Place getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(Place fromLocation) {
        this.fromLocation = fromLocation;
    }

    public Place getToLocation() {
        return toLocation;
    }

    public void setToLocation(Place toLocation) {
        this.toLocation = toLocation;
    }

    public int getNumOfPassengers() {
        return numOfPassengers;
    }

    public void setNumOfPassengers(int numOfPassengers) {
        this.numOfPassengers = numOfPassengers;
    }

    public String getOnWardDate() {
        return onWardDate;
    }

    public void setOnWardDate(String onWardDate) {
        this.onWardDate = onWardDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public int getAdultCount() {
        return adultCount;
    }

    public void setAdultCount(int adultCount) {
        this.adultCount = adultCount;
    }

    public int getChildrenCount() {
        return childrenCount;
    }

    public void setChildrenCount(int childrenCount) {
        this.childrenCount = childrenCount;
    }

    public void setTextlanguage(String textlanguage) {
        this.textlanguage = textlanguage;
    }

    public String getTextlanguage() {
        return textlanguage;
    }

    public void setSingleLady(int singleLady) {
        this.singleLady = singleLady;
    }

    public int getSingleLady() {
        return singleLady;
    }

    public void setAdultFemaleCount(int adultFemaleCount) {
        this.adultFemaleCount = adultFemaleCount;
    }

    public int getAdultFemaleCount() {
        return adultFemaleCount;
    }
}
