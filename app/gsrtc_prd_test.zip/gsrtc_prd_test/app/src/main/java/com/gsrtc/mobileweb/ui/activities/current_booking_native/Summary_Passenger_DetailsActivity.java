package com.gsrtc.mobileweb.ui.activities.current_booking_native;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.gsrtc.mobileweb.R;
import com.gsrtc.mobileweb.models.BusSummaryDetails;
import com.gsrtc.mobileweb.models.Passenger;
import com.gsrtc.mobileweb.models.SaveCurrentBookingDetailsTemporarilyResponse;
import com.gsrtc.mobileweb.models.SearchParamsCurrent;
import com.gsrtc.mobileweb.ui.activities.advance_booking.PassengerInfoActivity;
import com.gsrtc.mobileweb.ui.activities.base.BaseNavigationDrawerActivity;
import com.gsrtc.mobileweb.utils.ActivityUtil;
import com.gsrtc.mobileweb.utils.AppConstants;
import com.gsrtc.mobileweb.utils.SoapClientUtil;
import com.gsrtc.mobileweb.utils.ValidationUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by bala on 01-01-2018.
 */

public class Summary_Passenger_DetailsActivity extends BaseNavigationDrawerActivity{

    SearchParamsCurrent searchParams;
    ActivityViewHolder vHolder;
    boolean dataFetched = false;
    BusSummaryDetails busSummaryDetails;
    private String isCard;
    SaveCurrentBookingDetailsTemporarilyResponse saveTempDetails;
    PassengerListAdapter2 passengerListAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentViewDrawer(R.layout.get_current_summary_passenger_details);

        Log.e("Summary ::", "OnCreate");

        if(getIntent()!=null && getIntent().getExtras()!=null){

            searchParams = (SearchParamsCurrent) getIntent().getExtras().getSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM);

        }

        setupViews();
    }

    public void setupViews() {
        vHolder = new ActivityViewHolder(this);
        passengerListAdapter = new PassengerListAdapter2(this, searchParams.getAdultCount() + searchParams.getChildrenCount());

        if(!dataFetched){
            vHolder.loadingLayout.setVisibility(View.VISIBLE);
            vHolder.scrollViewPassengerInfo.setVisibility(View.GONE);
        }
        vHolder.recycler_view.setAdapter(passengerListAdapter);
        vHolder.recycler_view.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
        ActivityUtil.setListViewHeightBasedOnChildren(vHolder.recycler_view);
        passengerListAdapter.notifyDataSetChanged();
        fetchSummaryDetails();
    }


    public void fetchSummaryDetails(){

        SoapClientUtil.getSummaryDetails(searchParams, new SoapClientUtil.GetCurrentTotalFareDetailsOfTicketCallback() {

            @Override
            public void onSuccess(BusSummaryDetails summaryDetails) {
                busSummaryDetails = summaryDetails;

                vHolder.loadingLayout.setVisibility(View.GONE);
                vHolder.scrollViewPassengerInfo.setVisibility(View.VISIBLE);

                vHolder.textViewDate.setText(busSummaryDetails.getJourneyDate());
                //searchParams.getFromLocation().getPlaceName() + " to " + searchParams.getToLocation().getPlaceName()
                vHolder.textViewFrom.setText(searchParams.getFromLocation().getPlaceName());
                vHolder.textViewTo.setText(searchParams.getToLocation().getPlaceName());
                vHolder.textViewService.setText(searchParams.getServiceRouteName());
                vHolder.textViewNoSeats.setText(String.valueOf(searchParams.getAdultCount() + searchParams.getChildrenCount()));

                vHolder.radio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                        RadioButton button = (RadioButton) group.findViewById(checkedId);
                        if (button.getText().toString().equalsIgnoreCase("HDFC")) {
                            isCard = "694";
                        } else {
                            isCard = "175";
                        }
                    }
                });

                vHolder.btnSaveTempButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        List<Passenger> passengers = passengerListAdapter.getPassengerDetails();
                        if(TextUtils.isEmpty(vHolder.editTextPassengerEmail.getText().toString()) && TextUtils.isEmpty(vHolder.editTextPassengerMobile.getText().toString())){
                            ActivityUtil.showSnackBar(vHolder.rootView, "Please enter Passenger Details");
                            return;
                        }else {

                            if(!ValidationUtil.isValidEmail(vHolder.editTextPassengerEmail.getText())){
                                ActivityUtil.showSnackBar(vHolder.rootView, "Please enter valid email");
                                return;
                            }
                            else if(vHolder.editTextPassengerMobile.getText().length() != 10){
                                ActivityUtil.showSnackBar(vHolder.rootView, "Phone number must be 10 digit long");
                                return;
                            }

                            else if(!ValidationUtil.isValidPhone(vHolder.editTextPassengerMobile.getText())){
                                ActivityUtil.showSnackBar(vHolder.rootView, "Please enter valid phone");
                                return;
                            }else {

                                ArrayList<String> passengerList= new ArrayList<String>();

                                for(int i = 0; i< passengers.size() ; i++){
                                    Passenger passenger = passengers.get(i);
                                    PassengerListAdapter2.ViewHolder view = null;

                                    if(TextUtils.isEmpty(passenger.getPassengerName())){
                                        ActivityUtil.showSnackBar(vHolder.rootView, "Passenger name cannot be empty");
                                        view = (view!=null)?view:passengerListAdapter.getViewHolder(i);
                                        view.passengerName.requestFocus();
                                        return;
                                    }else {

                                        passengerList.add(passenger.getPassengerName());
                                    }
                                }

                                String pss = TextUtils.join(",", passengerList);
                                String passengerMain = passengerList.get(0);
                                Log.e("P Names", pss);
                                Log.e("P Main", passengerMain);

                            searchParams.setPassengerName(pss);
                            searchParams.setPassengerEmail(vHolder.editTextPassengerEmail.getText().toString());
                            searchParams.setPassengerMobile(vHolder.editTextPassengerMobile.getText().toString());

                            saveDetailsTemp();
                        }

                        }
                    }
                });

                showLoading(false);
            }

            @Override
            public void onError(Exception e) {

                ActivityUtil.showErrorToast(Summary_Passenger_DetailsActivity.this, e);

            }
        });
    }

    public void saveDetailsTemp(){

        showLoading(true);
        SoapClientUtil.saveTempDetails(searchParams,isCard, new SoapClientUtil.SaveCurrentBookingDetailsTemporarilyCallback() {

            @Override
            public void onSuccess(SaveCurrentBookingDetailsTemporarilyResponse saveTempDetailsRES) {

                showLoading(false);

                saveTempDetails = saveTempDetailsRES;

                searchParams.setAdultTicketFareSaveCurrentBookingDetailsTemporarilyResponse(saveTempDetailsRES.getAdultTicketFare());
                searchParams.setChildTicketFareSaveCurrentBookingDetailsTemporarilyResponse(saveTempDetailsRES.getChildTicketFare());
                searchParams.setGsrtcRefNoSaveCurrentBookingDetailsTemporarilyResponse(saveTempDetailsRES.getKsrtcRefNo());
                searchParams.setPnrMasterIDSaveCurrentBookingDetailsTemporarilyResponse(saveTempDetailsRES.getPnrMasterID());
                searchParams.setPnrNumberSaveCurrentBookingDetailsTemporarilyResponse(saveTempDetailsRES.getPnrNumber());
                searchParams.setGatewayLookupId(isCard);
//                if (isCard) {
//
//                    searchParams.setGatewayBILLDESK("BILLDESK");
//
//                } else {
//
//                    searchParams.setGatewayHDFC("HDFC");
//
//                }

                Bundle extra = new Bundle();
                extra.putSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM, searchParams);
                ActivityUtil.openNewActivity(Summary_Passenger_DetailsActivity.this, CurrentReferenceNumberActivity.class, extra);

            }

            @Override
            public void onError(Exception e) {
                showLoading(false);
                ActivityUtil.showErrorToast(Summary_Passenger_DetailsActivity.this, e);

            }
        });
    }

    public static class ActivityViewHolder{
        View rootView, loadingLayout;
        ScrollView scrollViewPassengerInfo;
        TextView textViewDate;
        TextView textViewFrom;
        TextView textViewTo;
        TextView textViewService;
        TextView textViewNoSeats;
        Button btnSaveTempButton;
        //EditText editTextPassengerName;
        EditText editTextPassengerEmail;
        EditText editTextPassengerMobile;
        RadioGroup radio;
        RadioButton cards;
        RadioButton net;
        ListView recycler_view;


        ActivityViewHolder(Activity activity){
            rootView = activity.findViewById(R.id.rootView);
            //header_text = (TextView)activity.findViewById(R.id.header_text);
            //swipeContainer = (SwipeRefreshLayout) activity.findViewById(R.id.swipeContainer);
            loadingLayout =  activity.findViewById(R.id.search_results_loading);
            scrollViewPassengerInfo = (ScrollView) activity.findViewById(R.id.scrollViewPassengerSummary);
            textViewDate = (TextView) activity.findViewById(R.id.tvSummaryDateValue);
            textViewFrom = (TextView) activity.findViewById(R.id.tvSummaryFromValue);
            textViewTo = (TextView) activity.findViewById(R.id.tvSummaryToValue);
            textViewService = (TextView) activity.findViewById(R.id.tvSummaryServiceValue);
            textViewNoSeats = (TextView) activity.findViewById(R.id.tvSummaryNoOfSeatsValue);
            //editTextPassengerName = (EditText) activity.findViewById(R.id.edt_passenger_name);
            editTextPassengerEmail = (EditText) activity.findViewById(R.id.email);
            editTextPassengerMobile = (EditText) activity.findViewById(R.id.phone);
            radio = (RadioGroup) activity.findViewById(R.id.radio);
            cards = (RadioButton) activity.findViewById(R.id.cards);
            net = (RadioButton) activity.findViewById(R.id.net_banking);
            btnSaveTempButton = (Button) activity.findViewById(R.id.btnConfirmSummary);
            recycler_view = (ListView) activity.findViewById(R.id.recycler_view);


            ActivityUtil.loadLoadingImage(activity, (ImageView)activity.findViewById(R.id.loading_gif));
        }
    }

    public void showLoading(boolean show){
        if(show){
            vHolder.loadingLayout.setVisibility(View.VISIBLE);
        }
        else{
            vHolder.loadingLayout.setVisibility(View.GONE);
        }
    }

    static class PassengerListAdapter2 extends BaseAdapter {

        Context context;
        int passengerCount;
        Map<Integer, PassengerListAdapter2.ViewHolder> viewMap;

        List<Passenger> passengers;

        PassengerListAdapter2(Context context, int passengerCount){
            this.context = context;
            this.passengerCount = passengerCount;
            viewMap = new LinkedHashMap<>();
            this.passengers = new ArrayList<>(passengerCount);
        }

        @Override
        public int getCount() {
            return passengerCount;
        }

        @Override
        public Object getItem(int i) {
            return passengers.get(i);
        }

        public PassengerListAdapter2.ViewHolder getViewHolder(int position){
            if(viewMap.containsKey(position))
                return viewMap.get(position);
            else
                return null;
        }

        public List<Passenger> getPassengerDetails(){
            List<Passenger> passengers = new ArrayList<>();
            String[] genderrray = context.getResources().getStringArray(R.array.gender_array);
            for (Map.Entry<Integer, PassengerListAdapter2.ViewHolder> entry : viewMap.entrySet())
            {
                PassengerListAdapter2.ViewHolder viewHolder = entry.getValue();
                Passenger passenger = new Passenger();
                passenger.setPassengerName(viewHolder.passengerName.getText().toString());

                passengers.add(passenger);
            }
            return passengers;
        }



        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup viewGroup) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).
                        inflate(R.layout.passengerinfo_list_item, viewGroup, false);
            }
            viewMap.put(position, new PassengerListAdapter2.ViewHolder(convertView));
            return convertView;
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            EditText passengerName;

            public ViewHolder(View itemView) {
                super(itemView);
                passengerName = (EditText)itemView.findViewById(R.id.passenger_name);
                passengerName.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);


            }
        }
    }
}
