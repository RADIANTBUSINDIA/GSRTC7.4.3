package com.gsrtc.mobileweb.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Ajith on 01/13/2020.
 */

public class Gsrtc_local_db extends SQLiteOpenHelper
{
    private static String DB_NAME = "GSRTC_DB.sqlite";
    private static int DB_VERSION = 2;
    private static Gsrtc_local_db mObj;
    private String mCreateTableLastSearch="CREATE TABLE LAST_SEARCH(_id INTEGER primary key autoincrement,_source_city_id varchar,_source_city_code varchar," +
            "_source_city_name varchar,_dest_city_id varchar,_dest_city_code varchar,_dest_city_name varchar," +
            "_journey_date long,_return_date long,_adult INTEGER,_datefordb TIMESTAMP)";

    private String mCreateTableMyAccount="CREATE TABLE MY_ACCOUNT(_tier_status varchar,_total_Points_Earned varchar,_redeemed_points varchar," +
            "_available_points varchar,_val_of_points varchar,_point_to_next_tier varchar,_bi_membership_no varchar, _balance varchar)";

    private String mCreateTableBusTransaction="CREATE TABLE BUS_TRANSACTION(_fromPlace varchar,_toPlace varchar,_dateOfjourney TIMESTAMP," +
            "_pnrNo varchar,_itineraryNo varchar,_hiddenServiceLogoPath varchar,_ticketStatus varchar,_obNo varchar,_travel_name varchar," +
            "_via_place varchar,_passenger_name varchar,_seat_no varchar,_depart_time varchar,_arrival_time varchar,_fare varchar,_datefordb TIMESTAMP,_stuid varchar, _bookingType TEXT)";



    private String mCreateTablePushIds="CREATE TABLE PUSHIDS(_id INTEGER PRIMARY KEY)";

    private Gsrtc_local_db(Context context, String name, SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, DB_NAME, factory, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // TODO Auto-generated method stub

        db.execSQL(mCreateTableLastSearch);
        db.execSQL(mCreateTablePushIds);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // TODO Auto-generated method stub
        while (oldVersion < newVersion)
        {
            switch (oldVersion)
            {
                case 1:
                {
                    db.execSQL(mCreateTablePushIds);
                    oldVersion++;
                }
                break;
                default:
                    break;
            }
        }
    }
    public static Gsrtc_local_db GET_DB_Instance(Context con)
    {
        if (mObj == null)
        {
            mObj = new Gsrtc_local_db(con, DB_NAME, null, DB_VERSION);
            return mObj;
        } else {
            return mObj;
        }
    }
    public void sInsert_LastSearch(String s_city_id, String s_city_code, String s_city_name, String d_city_id,
                                   String d_city_code, String d_city_name, String journeyDate, String returnDate, int adult, String datefordb)
    {
        ContentValues mCv = new ContentValues();
        mCv.put("_source_city_id", s_city_id);
        mCv.put("_source_city_code", s_city_code);
        mCv.put("_source_city_name", s_city_name);
        mCv.put("_dest_city_id", d_city_id);
        mCv.put("_dest_city_code", d_city_code);
        mCv.put("_dest_city_name", d_city_name);
        mCv.put("_journey_date", journeyDate);
        mCv.put("_return_date", returnDate);
        mCv.put("_adult", adult);
        mCv.put("_datefordb",datefordb);
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert("LAST_SEARCH", null, mCv);
    }
    public Cursor mGetLastSearch()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String Query = "SELECT * FROM LAST_SEARCH";
        return db.rawQuery(Query, null);
    }
    public Cursor mGetLastAllSearch(String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String Query = "SELECT * FROM LAST_SEARCH where _datefordb >='" + date + "' ORDER BY _id DESC";
        Log.e("-------------","SELECT * FROM LAST_SEARCH where _datefordb >='" + date + "' ORDER BY _id DESC");
        return db.rawQuery(Query, null);
    }
    public void deleteLastSearchMoreThenFive(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String deleteQuery = "DELETE FROM LAST_SEARCH where rowid='" + id + "'";
        db.execSQL(deleteQuery);
    }
    public void deleteLastSearchAll()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("LAST_SEARCH", null, null);
    }

    public void sClear_Temp_Bundle(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from TEMP_BUNDLE");
        Log.e("Bundle Data Deleted", "successfully");
    }


    public void mDeleteTable(String tableName)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(tableName, null, null);
        Log.e("","deleted table: "+tableName);
    }
}


