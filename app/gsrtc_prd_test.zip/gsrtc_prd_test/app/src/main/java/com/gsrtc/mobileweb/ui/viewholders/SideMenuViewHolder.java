package com.gsrtc.mobileweb.ui.viewholders;

import android.app.Activity;
import android.support.v4.widget.DrawerLayout;

/**
 * Created by Swastik on 4/5/2017.
 */

public class SideMenuViewHolder {
    DrawerLayout drawer;
    SideMenuViewHolder(Activity activity, ToolbarViewHolder toolbarViewHolder){

    }
}
