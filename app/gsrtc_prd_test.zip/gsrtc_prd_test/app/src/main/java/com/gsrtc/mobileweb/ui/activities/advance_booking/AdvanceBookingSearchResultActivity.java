package com.gsrtc.mobileweb.ui.activities.advance_booking;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import com.codetroopers.betterpickers.calendardatepicker.CalendarDatePickerDialogFragment;
import com.codetroopers.betterpickers.calendardatepicker.MonthAdapter;
import com.gsrtc.mobileweb.R;
import com.gsrtc.mobileweb.models.AddBlockSeatsResponse;
import com.gsrtc.mobileweb.models.Booking;
import com.gsrtc.mobileweb.models.BusService;
import com.gsrtc.mobileweb.models.SearchParams;
import com.gsrtc.mobileweb.models.SearchParamsCurrent;
import com.gsrtc.mobileweb.models.Seat;
import com.gsrtc.mobileweb.ui.activities.base.BaseNavigationDrawerActivity;
import com.gsrtc.mobileweb.utils.ActivityUtil;
import com.gsrtc.mobileweb.utils.AppConstants;
import com.gsrtc.mobileweb.utils.SoapClientUtil;
import com.gsrtc.mobileweb.utils.customdialog.CustomisedProgressDialog;


public class AdvanceBookingSearchResultActivity extends BaseNavigationDrawerActivity  {

    SearchResultAdapter searchResultAdapter;
    SearchParams searchParams;
    private Date mJourneyStartDate;
    private Date mReturnStartDate;
    private SimpleDateFormat mSmpDtFrmt;
    private SimpleDateFormat mSmpDtFrmtCall;
    Booking onwardBooking;
    Booking returnBooking;
    ActivityViewHolder vHolder;
    boolean dataFetched = false;
    private int mIndex;
    ProgressDialog progressDialog;
    CalendarDatePickerDialogFragment calendarDialog;
    private String textlang,discfare;

    public enum SORT_METHOD{
        DEP_TIME, CLASS, PRICE;
    }
    public static int SEAT_SELECTION_REQUEST = 1;
    List<BusService> busServiceList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentViewDrawer(R.layout.activity_advance_booking_search_result);

        mSmpDtFrmt = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
        mSmpDtFrmtCall = new SimpleDateFormat("dd/MM/yyyy");

        if(getIntent()!=null && getIntent().getExtras()!=null){
            Bundle mBun = getIntent().getExtras();
            textlang =mBun.getString("textlang");
            searchParams = (SearchParams) getIntent().getExtras().getSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM);
        }

        setupViews();
    }

    public void setupViews(){
        vHolder = new ActivityViewHolder(this);

        vHolder.header_text.setText(searchParams.getFromLocation().getPlaceName()+" to "+searchParams.getToLocation().getPlaceName()+" - "+searchParams.getOnWardDate());
        setupListView(null);
        vHolder.swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                CustomisedProgressDialog.SHOW_CUST_DIA(AdvanceBookingSearchResultActivity.this, "Searching Buses...");

                if(!dataFetched){
                    vHolder.loadingLayout.setVisibility(View.VISIBLE);
                    vHolder.recyclerView.setVisibility(View.GONE);
                }
                vHolder.swipeContainer.setRefreshing(false);
                CustomisedProgressDialog.STOP_CUST_DIA();
                fetchAvailableServices();
            }
        });


        vHolder.dep_time_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSortBtnClick(view);
            }
        });
        vHolder.class_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSortBtnClick(view);
            }
        });
        vHolder.price_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSortBtnClick(view);
            }
        });
        vHolder.PreviousDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSortBtnimageClick(view);
            }
        });
        vHolder.NextDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSortBtnimageClick(view);
            }
        });
        fetchAvailableServices();
    }

    public void setupListView(List<BusService> serviceList){

        searchResultAdapter = new SearchResultAdapter(this, serviceList) {

            @Override
            public void onItemClick(BusService busService) {
                Bundle extra = new Bundle();
                extra.putString("textlang", textlang);
                extra.putSerializable(AppConstants.INTENT_EXTRA.BUS_SERVICE, busService);
                extra.putSerializable(AppConstants.INTENT_EXTRA.SEARCH_PARAM, searchParams);
                Intent intent = new Intent(AdvanceBookingSearchResultActivity.this, SeatSelectionActivity.class);
                intent.putExtras(extra);
                startActivityForResult(intent, SEAT_SELECTION_REQUEST);
            }
        };
        LinearLayoutManager layoutManager  = new LinearLayoutManager(this);
        vHolder.recyclerView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(vHolder.recyclerView.getContext(),
                layoutManager.getOrientation() );
        vHolder.recyclerView.addItemDecoration(dividerItemDecoration);
        vHolder.recyclerView.setAdapter(searchResultAdapter);
        searchResultAdapter.notifyDataSetChanged();
    }

    public void onSortBtnClick(View v){
        if(busServiceList == null || busServiceList.isEmpty()){
            return;
        }
        vHolder.dep_time_btn.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        vHolder.class_btn.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        vHolder.price_btn.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        vHolder.PreviousDay.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        vHolder.NextDay.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        vHolder.dep_time_btn.setTextColor(getResources().getColor(R.color.black));
        vHolder.class_btn.setTextColor(getResources().getColor(R.color.black));
        vHolder.price_btn.setTextColor(getResources().getColor(R.color.black));
//        vHolder.PreviousDay.setTextColor(getResources().getColor(R.color.black));
//        vHolder.NextDay.setTextColor(getResources().getColor(R.color.black));

        v.setBackgroundColor(getResources().getColor(R.color.yellowlight));
        ((Button) v).setTextColor(getResources().getColor(R.color.white));
        switch (v.getId()) {
            case R.id.dep_time_btn:
                sortList(busServiceList, SORT_METHOD.DEP_TIME);
                setupListView(busServiceList);
                break;
            case R.id.class_btn:
                sortList(busServiceList, SORT_METHOD.CLASS);
                setupListView(busServiceList);
                break;
            case R.id.price_btn:
                sortList(busServiceList, SORT_METHOD.PRICE);
                setupListView(busServiceList);
                break;
        }
    }


    public void onSortBtnimageClick(View v) {
        if (busServiceList == null || busServiceList.isEmpty()) {
            return;
        }

        vHolder.PreviousDay.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        vHolder.NextDay.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        v.setBackgroundColor(getResources().getColor(R.color.yellowlight));
        switch (v.getId()) {
            case R.id.nextDay:
                nextsearch();
                setupListView(busServiceList);
                break;

            case R.id.previousDay:
                lastsearch();
                setupListView(busServiceList);
                break;
        }
    }


    public void sortList(List<BusService> unsortedList, SORT_METHOD sort_method){
        if(unsortedList == null || unsortedList.isEmpty()){
            return;
        }
        if(sort_method.equals(SORT_METHOD.DEP_TIME)){
            Collections.sort(unsortedList, new Comparator<BusService>() {
                @Override
                public int compare(BusService a1, BusService a2) {
                    int comp = 0;
                    try {
                        comp = new SimpleDateFormat("HH:mm").parse(a1.getDepartureTime()).compareTo(new SimpleDateFormat("HH:mm").parse(a2.getDepartureTime()));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    return comp;
                }
            });
        }

        else if(sort_method.equals(SORT_METHOD.CLASS)){
            Collections.sort(unsortedList, new Comparator<BusService>() {
                @Override
                public int compare(BusService a1, BusService a2) {
                    return -a1.getServiceClass().compareTo(a2.getServiceClass());
                }
            });
        }
        else if(sort_method.equals(SORT_METHOD.PRICE)){
            Collections.sort(unsortedList, new Comparator<BusService>() {
                @Override
                public int compare(BusService a1, BusService a2) {
                    return ((Double)Math.ceil(Double.parseDouble(a1.getAdultFare()) - Double.parseDouble(a2.getAdultFare()))).intValue();
                }
            });
        }
    }


    public void fetchAvailableServices(){

        CustomisedProgressDialog.SHOW_CUST_DIA(AdvanceBookingSearchResultActivity.this, "Searching Buses...");

        SoapClientUtil.getAvailableServiceDetails(searchParams, (onwardBooking != null), new SoapClientUtil.GetAvailableServiceDetailsCallback() {
            @Override
            public void onSuccess(List<BusService> serviceList) {
                if(serviceList.size() == 0){
                    if(onwardBooking== null){
                        //No list for onward booking
                        setResult(RESULT_OK);
                        finish();
                    }else{
                        onEmptyResultForReturnJourney();
                    }
                }

                CustomisedProgressDialog.STOP_CUST_DIA();
                busServiceList = serviceList;

                //   sortList(busServiceList, SORT_METHOD.DEP_TIME);
                onSortBtnClick(vHolder.dep_time_btn);
                // setupListView(busServiceList);

                searchResultAdapter.notifyDataSetChanged();
                vHolder.loadingLayout.setVisibility(View.GONE);
                vHolder.recyclerView.setVisibility(View.VISIBLE);
                showLoading(false);
            }

            @Override
            public void onError(Exception e) {
                vHolder.loadingLayout.setVisibility(View.GONE);
                showLoading(false);
                CustomisedProgressDialog.STOP_CUST_DIA();
                ActivityUtil.showErrorToast(AdvanceBookingSearchResultActivity.this, e);
            }
        });
    }

    public void showLoading(boolean show){
        if(show){
            vHolder.loadingLayout.setVisibility(View.VISIBLE);
        }
        else{
            vHolder.loadingLayout.setVisibility(View.GONE);
        }
    }

    public void loadViewForReturnJourney(){
        showLoading(true);
        vHolder.header_text.setText(searchParams.getToLocation().getPlaceName()+" to "+searchParams.getFromLocation().getPlaceName()+" - "+searchParams.getReturnDate()+" (Return Journey)");
        searchResultAdapter.clear();
        searchResultAdapter.notifyDataSetChanged();
        fetchAvailableServices();
    }

    public class ActivityViewHolder{
        View rootView, loadingLayout;
        RecyclerView recyclerView;
        TextView header_text;
        SwipeRefreshLayout swipeContainer;
        Button dep_time_btn, class_btn, price_btn;
        ImageButton PreviousDay,NextDay;
        ActivityViewHolder(Activity activity){
            rootView = activity.findViewById(R.id.rootView);
            header_text = (TextView)activity.findViewById(R.id.header_text);
            swipeContainer = (SwipeRefreshLayout) activity.findViewById(R.id.swipeContainer);
            loadingLayout =  activity.findViewById(R.id.search_results_loading);
            recyclerView = (RecyclerView) activity.findViewById(R.id.search_results_recycler_view);

            dep_time_btn =  (Button)activity.findViewById(R.id.dep_time_btn);
            class_btn =  (Button)activity.findViewById(R.id.class_btn);
            price_btn =  (Button)activity.findViewById(R.id.price_btn);
            PreviousDay =  (ImageButton) activity.findViewById(R.id.previousDay);
            NextDay =  (ImageButton) activity.findViewById(R.id.nextDay);
            if(textlang.equalsIgnoreCase("gujarati"))
            {
                dep_time_btn.setText(R.string.serv_dep_time);
                class_btn.setText(R.string.serv_class);
                price_btn.setText(R.string.serv_price);
            }
            //ActivityUtil.loadLoadingImage(activity, (ImageView)activity.findViewById(R.id.loading_gif));
        }
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SEAT_SELECTION_REQUEST) {
            if (resultCode == RESULT_OK) {
                if (data!=null && data.getExtras() != null) {
                    Bundle bundle = data.getExtras();
                    if(onwardBooking == null){  //It means, the result is for onward booking
                        onwardBooking = new Booking();
                        onwardBooking.setBusService((BusService) bundle.getSerializable(AppConstants.INTENT_EXTRA.BUS_SERVICE));
                        //onwardBooking.setReferenceNumberResponse((GetReferenceNumberResponse) bundle.getSerializable(AppConstants.INTENT_EXTRA.REFERENCE_NUMBER));
                        onwardBooking.setIsReturn(false);
                        onwardBooking.setTextlanguage(textlang);
                        onwardBooking.setSearchParams(searchParams);
                        onwardBooking.setSelectedSeats((ArrayList<Seat>) bundle.getSerializable(AppConstants.INTENT_EXTRA.SELECTED_SEATS));
                        onwardBooking.setStartPlace(searchParams.getFromLocation());
                        onwardBooking.setEndPlace(searchParams.getToLocation());
                        onwardBooking.setJourneyDate(searchParams.getOnWardDate());
                        onwardBooking.setAddBlockSeatsResponse((AddBlockSeatsResponse) bundle.getSerializable(AppConstants.INTENT_EXTRA.ADD_BLOCK_SEATS_RESPONSE));
                    }
                    else{       //Means the result if for return booking
                        returnBooking = new Booking();
                        returnBooking.setBusService((BusService) bundle.getSerializable(AppConstants.INTENT_EXTRA.BUS_SERVICE));
                        //returnBooking.setReferenceNumberResponse((GetReferenceNumberResponse) bundle.getSerializable(AppConstants.INTENT_EXTRA.REFERENCE_NUMBER));
                        returnBooking.setIsReturn(true);
                        returnBooking.setTextlanguage(textlang);
                        returnBooking.setSearchParams(searchParams);
                        returnBooking.setSelectedSeats((ArrayList<Seat>) bundle.getSerializable(AppConstants.INTENT_EXTRA.SELECTED_SEATS));
                        returnBooking.setStartPlace(searchParams.getToLocation());
                        returnBooking.setEndPlace(searchParams.getFromLocation());
                        returnBooking.setJourneyDate(searchParams.getReturnDate());
                        returnBooking.setAddBlockSeatsResponse((AddBlockSeatsResponse) bundle.getSerializable(AppConstants.INTENT_EXTRA.ADD_BLOCK_SEATS_RESPONSE));

                        Bundle extras = new Bundle();
                        extras.putString("textlang", textlang);
                        extras.putSerializable(AppConstants.INTENT_EXTRA.BOOKING_ONWARD, onwardBooking);
                        extras.putSerializable(AppConstants.INTENT_EXTRA.BOOKING_RETURN, returnBooking);
                        ActivityUtil.openNewActivity(this, PassengerInfoActivity.class, extras);
                    }
                    if(searchParams.getReturnDate() == null){   //No return date has to be selected
                        Bundle extras = new Bundle();
                        extras.putString("textlang", textlang);
                        extras.putSerializable(AppConstants.INTENT_EXTRA.BOOKING_ONWARD, onwardBooking);
                        ActivityUtil.openNewActivity(this, PassengerInfoActivity.class, extras);
                    }
                    else{           //return date has to be selected
                        loadViewForReturnJourney();
                    }
                }
            }
        }
    }


    static abstract class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.ViewHolder>{

        private List<BusService> busList;
        Context context;


        public SearchResultAdapter(Context context, List<BusService> busList) {
            if(busList == null)
                busList = new ArrayList<BusService>();
            this.busList = busList;
            this.context = context;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            Context context = parent.getContext();
            LayoutInflater inflater = LayoutInflater.from(context);

            // Inflate the custom layout
            View contactView = inflater.inflate(R.layout.advance_booking_list_item, parent, false);

            // Return a new holder instance
            return new ViewHolder(contactView);
        }

        @Override
        public void onBindViewHolder(SearchResultAdapter.ViewHolder holder, int position) {
            BusService busService = this.busList.get(position);

            holder.container.setTag(position);
            holder.container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Integer pos = (Integer)view.getTag();
                    onItemClick(busList.get(pos));
                }
            });
            holder.booking_class.setText(busService.getServiceClass());
            holder.departure_time.setText(busService.getDepartureTime()+":00");
           // holder.actual_price.setText("INR "+busService.getAdultFare());
            holder.price.setText("INR "+busService.getAdultFare());
            holder.bus_route.setText(busService.getOrigin()+" - "+busService.getDestination());
            holder.arrival_time.setText(busService.getArrivalTime());
            holder.tripco.setText(busService.getTripCode());
            holder.journey_hours.setText(busService.getJourneyHours()+"hrs");

//            if(busService.getServiceClass().equalsIgnoreCase("VOLVO SLEEPER") || busService.getServiceClass().equalsIgnoreCase("AC SLEEPER")|| busService.getServiceClass().equalsIgnoreCase("VOLVO")|| busService.getServiceClass().equalsIgnoreCase("AC LUXURY")){
//                int actualPrice=Integer.parseInt(busService.getAdultFare());
//                int per=actualPrice*10/100;
//                int discfare= actualPrice-per;
//                holder.price.setText("INR "+discfare);
//
//            }else{
//
//                int actualPrice=Integer.parseInt(busService.getAdultFare());
//                int per=actualPrice*8/100;
//                int discfare= actualPrice-per;
//                holder.price.setText("INR "+discfare);
//            }

            if(busService.getNoOfSeats().equalsIgnoreCase("0")){

                holder.seat_avail.setTextColor(Color.parseColor("#ff3333"));
                holder.seat_avail.setText("FULL");

            }else {

                holder.seat_avail.setTextColor(Color.parseColor("#00B700"));
                holder.seat_avail.setText(busService.getNoOfSeats() + " seats");
            }
            //holder.seat_avail.setText(busService.getNoOfSeats()+" seats");

        }
        // Clean all elements of the recycler
        public void clear() {
            busList.clear();
            notifyDataSetChanged();
        }

        // Add a list of items
        public void addAll(List<BusService> list) {
            busList.addAll(list);
            notifyDataSetChanged();
        }

        public abstract void onItemClick(BusService site);

        @Override
        public int getItemCount() {
            return busList.size();
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            TextView booking_class, bus_route, departure_time, price,journey_hours,arrival_time,seat_avail,tripco,actual_price;
            public View container;

            ViewHolder(View itemView) {
                super(itemView);
                container = itemView;
                booking_class = (TextView) itemView.findViewById(R.id.booking_class);
                bus_route = (TextView) itemView.findViewById(R.id.bus_route);
                journey_hours = (TextView) itemView.findViewById(R.id.journey_hours);
                arrival_time = (TextView) itemView.findViewById(R.id.arrival_time);
                seat_avail = (TextView) itemView.findViewById(R.id.no_seats);
                departure_time = (TextView) itemView.findViewById(R.id.departure_time);
                price = (TextView) itemView.findViewById(R.id.price);
                tripco = (TextView) itemView.findViewById(R.id.tripcode);
                actual_price = (TextView) itemView.findViewById(R.id.actual_price);
            }
        }
    }


    public void onEmptyResultForReturnJourney(){
        if(onwardBooking!=null){
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                    AdvanceBookingSearchResultActivity.this);

            alertDialog.setPositiveButton("Proceed", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Bundle extras = new Bundle();
                    extras.putString("textlang", textlang);
                    extras.putSerializable(AppConstants.INTENT_EXTRA.BOOKING_ONWARD, onwardBooking);
                    ActivityUtil.openNewActivity(AdvanceBookingSearchResultActivity.this, PassengerInfoActivity.class, extras);
                }
            });

            alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    AdvanceBookingSearchResultActivity.this.finish();
                }
            });

            alertDialog.setMessage("There is no services available for your return journey. Do you want to proceed with onward or cancel the booking?");
            alertDialog.setTitle("No services available");
            alertDialog.show();
        }
    }


    @Override
    public void onBackPressed() {
        if(onwardBooking !=null){
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                    AdvanceBookingSearchResultActivity.this,R.style.CustomDialogTheme);

            alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });

            alertDialog.setNegativeButton("No", null);

            alertDialog.setMessage("Going back will discard your booking. Do you want to continue?");
            alertDialog.setTitle("GSRTC");
            alertDialog.show();
        }
        else{
            finish();
        }
    }

    public  void lastsearch(){

        if (onwardBooking == null) {

            String mTempDate = searchParams.getOnWardDate().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
            Date mD = null;
            try {
                mD = sdf.parse(mTempDate);
            } catch (ParseException e1) {
                // 	TODO Auto-generated catch block
                e1.printStackTrace();
            }
            mJourneyStartDate = new Date();
            mJourneyStartDate.setTime(mD.getTime());
            //mProcessDateForServer(mSmpDtFrmt.format(mD));

            if ((mGetDaysDifferencePrevious(mCalculateDate(mJourneyStartDate, -1)) < 0)) {

                searchParams.setOnWardDate(mJourneyStartDate.toString());
                String jnyDate = mSmpDtFrmtCall.format(mJourneyStartDate);
                searchParams.setOnWardDate(jnyDate);
                CustomisedProgressDialog.STOP_CUST_DIA();
                ActivityUtil.showSnackBar(vHolder.rootView, "Sorry you can not book a ticket in previous day");

            } else {

                mJourneyStartDate = mCalculateDate(mJourneyStartDate, -1);
                searchParams.setOnWardDate(mJourneyStartDate.toString());
                String jnyDate = mSmpDtFrmtCall.format(mJourneyStartDate);
                searchParams.setOnWardDate(jnyDate);
                vHolder.header_text.setText(searchParams.getFromLocation().getPlaceName() + " to " + searchParams.getToLocation().getPlaceName() + " - " + searchParams.getOnWardDate());
                searchResultAdapter.clear();
                searchResultAdapter.notifyDataSetChanged();
                fetchAvailableServices();

            }
        }
        else {

            String mTempDate = searchParams.getReturnDate().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
            Date mD = null;
            try {
                mD = sdf.parse(mTempDate);
            } catch (ParseException e1) {
                // 	TODO Auto-generated catch block
                e1.printStackTrace();
            }
            mReturnStartDate = new Date();
            mReturnStartDate.setTime(mD.getTime());
            //mProcessDateForServer(mSmpDtFrmt.format(mD));

            if ((mGetDaysDifferencePrevious(mCalculateDate(mReturnStartDate, -1)) < 0)) {

                searchParams.setReturnDate(mReturnStartDate.toString());
                String rtnDate = mSmpDtFrmtCall.format(mReturnStartDate);
                searchParams.setReturnDate(rtnDate);
                CustomisedProgressDialog.STOP_CUST_DIA();
                ActivityUtil.showSnackBar(vHolder.rootView, "Sorry you can not book a ticket in previous day");

            } else {

                mReturnStartDate = mCalculateDate(mReturnStartDate, -1);
                searchParams.setReturnDate(mReturnStartDate.toString());
                String rtnDate = mSmpDtFrmtCall.format(mReturnStartDate);
                searchParams.setReturnDate(rtnDate);
                vHolder.header_text.setText(searchParams.getToLocation().getPlaceName() + " to " + searchParams.getFromLocation().getPlaceName() + " - " + searchParams.getReturnDate()+" (Return Journey)");
                searchResultAdapter.clear();
                searchResultAdapter.notifyDataSetChanged();
                fetchAvailableServices();

            }
        }
    }

    public void nextsearch(){

        if(onwardBooking==null) {

            String mTempDaten = searchParams.getOnWardDate().toString();
            SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
            Date mDd = null;
            try {
                mDd = sdf2.parse(mTempDaten);
            } catch (ParseException e1) {
                // 	TODO Auto-generated catch block
                e1.printStackTrace();
            }
            mJourneyStartDate = new Date();
            mJourneyStartDate.setTime(mDd.getTime());
            //mProcessDateForServer(mSmpDtFrmt.format(mDd));

            int diffDay = mGetDaysDifferenceForward(mCalculateDate(mJourneyStartDate, 1));
            if (diffDay < 60 && diffDay >= 0) {
                mJourneyStartDate = mCalculateDate(mJourneyStartDate, 1);
                searchParams.setOnWardDate(mJourneyStartDate.toString());
                String jnyDate = mSmpDtFrmtCall.format(mJourneyStartDate);
                searchParams.setOnWardDate(jnyDate);
                vHolder.header_text.setText(searchParams.getFromLocation().getPlaceName() + " to " + searchParams.getToLocation().getPlaceName() + " - " + searchParams.getOnWardDate());
                searchResultAdapter.clear();
                searchResultAdapter.notifyDataSetChanged();
                fetchAvailableServices();
            }
            else
            {
                searchParams.setOnWardDate(mJourneyStartDate.toString());
                String jnyDate = mSmpDtFrmtCall.format(mJourneyStartDate);
                searchParams.setOnWardDate(jnyDate);
                CustomisedProgressDialog.STOP_CUST_DIA();
                ActivityUtil.showSnackBar(vHolder.rootView, "Sorry you can book a ticket only in advance of 60 days");
            }
        }

        else {

            String mTempDaten = searchParams.getReturnDate().toString();
            SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
            Date mDd = null;
            try {
                mDd = sdf2.parse(mTempDaten);
            } catch (ParseException e1) {
                // 	TODO Auto-generated catch block
                e1.printStackTrace();
            }
            mReturnStartDate = new Date();
            mReturnStartDate.setTime(mDd.getTime());
           // mProcessDateForServer(mSmpDtFrmt.format(mDd));

            int diffDay = mGetDaysDifferenceForward(mCalculateDate(mReturnStartDate, 1));
            if (diffDay < 60 && diffDay >= 0) {
                mReturnStartDate = mCalculateDate(mReturnStartDate, 1);
                searchParams.setReturnDate(mReturnStartDate.toString());
                String rtnDate = mSmpDtFrmtCall.format(mReturnStartDate);
                searchParams.setReturnDate(rtnDate);
                vHolder.header_text.setText(searchParams.getToLocation().getPlaceName() + " to " + searchParams.getFromLocation().getPlaceName() + " - " + searchParams.getReturnDate()+" (Return Journey)");
                searchResultAdapter.clear();
                searchResultAdapter.notifyDataSetChanged();
                fetchAvailableServices();

            } else {

                searchParams.setReturnDate(mReturnStartDate.toString());
                String rtnDate = mSmpDtFrmtCall.format(mReturnStartDate);
                searchParams.setReturnDate(rtnDate);
                CustomisedProgressDialog.STOP_CUST_DIA();
                ActivityUtil.showSnackBar(vHolder.rootView, "Sorry you can book a ticket only in advance of 60 days");
            }
        }
    }

    private int mGetDaysDifferencePrevious(Date paramJourneyDate)
    {
        long mTime;
        Date mTodayDate = new Date();
        mTime=mTodayDate.getTime();

        long diff = mTime - paramJourneyDate.getTime();
        return((int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)*(-1));
    }

    private int mGetDaysDifferenceForward(Date paramJourneyDate)
    {

        Date mTodayDate = new Date();
        long diff = mTodayDate.getTime() - paramJourneyDate.getTime();
        return((int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)*(-1));

    }

    @SuppressLint("WrongConstant")
    private Date mCalculateDate(Date paramaDate, int paramDay)
    {
        Calendar c = Calendar.getInstance();
        c.setTime(paramaDate);
        c.add(Calendar.DATE, paramDay);
        return c.getTime();
    }

    private String mProcessDateForServer(String paramDate)
    {
        String mDateForWS="";
        String mDay= paramDate.trim().split(" ")[0];
        if(mDay.length()<2)
            mDay="0"+mDay;
        Months mMon = Months.valueOf(paramDate.trim().split(" ")[1]);
        switch (mMon)
        {
            case Jan:
                mDateForWS = mDay+"/01/"+ paramDate.trim().split(" ")[2];
                break;
            case Feb:
                mDateForWS = mDay+"/02/"+ paramDate.trim().split(" ")[2];
                break;
            case Mar:
                mDateForWS = mDay+"/03/"+ paramDate.trim().split(" ")[2];
                break;
            case Apr:
                mDateForWS = mDay+"/04/"+ paramDate.trim().split(" ")[2];
                break;
            case May:
                mDateForWS = mDay+"/05/"+ paramDate.trim().split(" ")[2];
                break;
            case Jun:
                mDateForWS = mDay+"/06/"+ paramDate.trim().split(" ")[2];
                break;
            case Jul:
                mDateForWS = mDay+"/07/"+ paramDate.trim().split(" ")[2];
                break;
            case Aug:
                mDateForWS = mDay+"/08/"+ paramDate.trim().split(" ")[2];
                break;
            case Sep:
                mDateForWS = mDay+"/09/"+ paramDate.trim().split(" ")[2];
                break;
            case Oct:
                mDateForWS = mDay+"/10/"+ paramDate.trim().split(" ")[2];
                break;
            case Nov:
                mDateForWS = mDay+"/11/"+ paramDate.trim().split(" ")[2];
                break;
            case Dec:
                mDateForWS = mDay+"/12/"+paramDate.trim().split(" ")[2];
                break;
            default:
                break;
        }
        if(onwardBooking==null) {
            searchParams.setOnWardDate(String.valueOf(mJourneyStartDate.getTime()));
        }else{
            searchParams.setReturnDate(String.valueOf(mReturnStartDate.getTime()));
        }
        return mDateForWS;
    }
    private enum Months
    {
        Jan,
        Feb,
        Mar,
        Apr,
        May,
        Jun,
        Jul,
        Aug,
        Sep,
        Oct,
        Nov,
        Dec
    }

    public  void showProgressDialog() {
        try {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
                progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
                progressDialog.setCancelable(false);
                progressDialog.show();
            } else {
                progressDialog.dismiss();
                progressDialog = new ProgressDialog(this);
                progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
                progressDialog.setCancelable(false);
                progressDialog.show();
            }
        } catch (Exception e) {

        }
    }
    public void hideProgressDialog() {
        if (progressDialog == null || !progressDialog.isShowing()) {
            return;
        }
        progressDialog.dismiss();
    }
}
