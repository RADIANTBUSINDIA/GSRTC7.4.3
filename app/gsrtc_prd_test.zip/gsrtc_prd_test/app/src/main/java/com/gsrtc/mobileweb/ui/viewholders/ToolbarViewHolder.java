package com.gsrtc.mobileweb.ui.viewholders;

import android.app.Activity;
import android.support.v7.widget.Toolbar;

import com.gsrtc.mobileweb.R;

/**
 * Created by Swastik on 4/5/2017.
 */

public class ToolbarViewHolder {
    Toolbar toolbar;
    ToolbarViewHolder(Activity activity){
       // toolbar = (Toolbar) activity.findViewById(R.id.toolbar);
    }
}
