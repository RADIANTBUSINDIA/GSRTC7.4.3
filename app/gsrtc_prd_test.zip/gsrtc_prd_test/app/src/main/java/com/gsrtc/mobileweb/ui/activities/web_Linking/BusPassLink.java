package com.gsrtc.mobileweb.ui.activities.web_Linking;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.gsrtc.mobileweb.R;
import com.gsrtc.mobileweb.ui.activities.HomeActivity;


public class BusPassLink extends AppCompatActivity {

    private WebView myWebView;
    String textlang,pass_opt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_pass_link);

        Bundle mBun = getIntent().getExtras();
        textlang =mBun.getString("textlang");
        pass_opt =mBun.getString("pass_opt");
        myWebView = (WebView) findViewById(R.id.webView);
        // Configure related browser settings
        myWebView.getSettings().setLoadsImagesAutomatically(true);
        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        // Configure the client to use when opening URLs
        myWebView.setWebViewClient(new MyBrowser());
        // Load the initial URL
        if(pass_opt.equalsIgnoreCase("New Commuter Bus Pass"))
        {
            myWebView.loadUrl("https://www.gsrtc.in/BUSPASS/preOnlinePassengerNewBusPassSystem.do?hiddenAction=PassengerNewBussPass");

        }else if(pass_opt.equalsIgnoreCase("Renewal Commuter Bus Pass")){

            myWebView.loadUrl("https://www.gsrtc.in/BUSPASS/preOnlinePassengerNewBusPassSystem.do?hiddenAction=PassengerRenewalBussPass");

        }else if(pass_opt.equalsIgnoreCase("Application Status")){

            myWebView.loadUrl("https://www.gsrtc.in/BUSPASS/preOnlinePassengerNewBusPassSystem.do?hiddenAction=PassengerApplicationStatus");

        }else{

            myWebView.loadUrl("https://drive.google.com/file/d/16xLbAbGph9DNjZCBC2zGiSuYEBey4B9N/view");
        }

    }

    private class MyBrowser extends WebViewClient {
        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            view.loadUrl(request.getUrl().toString());
            return true;
        }
    }
    @Override
    public void onBackPressed() {
        //ActivityUtil.openNewActivityAsOnlyActivity(Weblink.this, HomeActivity.class, null);
        Intent i = new Intent(BusPassLink.this, HomeActivity.class);
        Bundle data = new Bundle();
        data.putString("textlang", textlang);
        i.putExtras(data);
        startActivity(i);
    }
}

