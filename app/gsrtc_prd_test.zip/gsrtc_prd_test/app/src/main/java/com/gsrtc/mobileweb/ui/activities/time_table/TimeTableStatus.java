package com.gsrtc.mobileweb.ui.activities.time_table;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.gsrtc.mobileweb.R;

public class TimeTableStatus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_table_status);
    }
}
