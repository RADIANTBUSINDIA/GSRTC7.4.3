package com.gsrtc.mobileweb.ui.activities.payment_gateway;

/**
 * Created by Ajith on 6/21/2019.
 */

public class Constants {
    public static final String PARAMETER_SEP = "&";
    public static final String PARAMETER_EQUALS = "=";
    public static final String TRANS_URL = "https://secure.ccavenue.com/transaction/initTrans";
}