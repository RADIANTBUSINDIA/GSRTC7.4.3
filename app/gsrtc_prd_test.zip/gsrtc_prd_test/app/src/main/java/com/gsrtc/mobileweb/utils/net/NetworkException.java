package com.gsrtc.mobileweb.utils.net;

/**
 * Created by swastik on 5/5/17.
 */

public class NetworkException extends Exception {
}
